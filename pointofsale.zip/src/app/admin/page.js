import React from 'react'
import LayoutHeader from '../layoutHearTitle'

export default function Admin() {
    return (
        <div>  <LayoutHeader pageTitle="Admin" /></div>
    )
}
