(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_orders_completeorders_page_5887fa.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_orders_completeorders_page_5887fa.js",
  "chunks": [
    "static/chunks/node_modules_@mui_material_7cce40._.js",
    "static/chunks/node_modules_@mui_x-date-pickers_362694._.js",
    "static/chunks/node_modules_@popperjs_core_lib_b9b8df._.js",
    "static/chunks/node_modules_61ee52._.js",
    "static/chunks/src_9d12b3._.js"
  ],
  "source": "dynamic"
});
