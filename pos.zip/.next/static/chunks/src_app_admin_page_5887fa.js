(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_page_5887fa.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_page_5887fa.js",
  "chunks": [
    "static/chunks/_6ad3a6._.js"
  ],
  "source": "dynamic"
});
