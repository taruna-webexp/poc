(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_orders_allorders_page_5887fa.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_orders_allorders_page_5887fa.js",
  "chunks": [
    "static/chunks/node_modules_@mui_material_4e644b._.js",
    "static/chunks/node_modules_@mui_x-date-pickers_362694._.js",
    "static/chunks/node_modules_@popperjs_core_lib_b9b8df._.js",
    "static/chunks/node_modules_@dnd-kit_core_dist_core_esm_deb93f.js",
    "static/chunks/node_modules_556b44._.js",
    "static/chunks/src_6674f7._.js"
  ],
  "source": "dynamic"
});
