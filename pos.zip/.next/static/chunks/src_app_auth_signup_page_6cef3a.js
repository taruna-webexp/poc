(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_auth_signup_page_6cef3a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_auth_signup_page_6cef3a.js",
  "chunks": [
    "static/chunks/node_modules_@mui_material_8d6986._.js",
    "static/chunks/node_modules_cd0387._.js",
    "static/chunks/src_a92bde._.js"
  ],
  "source": "dynamic"
});
