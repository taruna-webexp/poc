(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_6cef3a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_6cef3a.js",
  "chunks": [
    "static/chunks/node_modules_fbd066._.js",
    "static/chunks/src_2106a2._.js"
  ],
  "source": "dynamic"
});
