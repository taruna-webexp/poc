(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_layout_6cef3a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_layout_6cef3a.js",
  "chunks": [
    "static/chunks/node_modules_045eb6._.js",
    "static/chunks/src_5a70a3._.js"
  ],
  "source": "dynamic"
});
