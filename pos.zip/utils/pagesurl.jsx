export const routesUrl = {
  order: "/admin/order",
  dashboard: "/admin/dashboard",
  signIn: "/auth/signin",
  signUp: "/auth/signup",
};
